<ul>
	<li><a href="https://wordpress.org/plugins/login-lockdown/" target="_blank">Login LockDown</a> (limit login attempts count)</li>
	<li><a href="https://wordpress.org/plugins/wp-facebook-login/" target="_blank">WP Facebook Login</a></li>
	<li><a href="https://wp-vote.net/" target="_blank">WP Foto Vote</a> (photo contest plugin from author of this plugin ☺)</li>
	<li>
        Logging & Debugging:
        <a href="https://wordpress.org/plugins/simple-history/" target="_blank">Simple History</a>
        &
        <a href="https://wordpress.org/plugins/log-emails/" target="_blank">Log Emails</a>
        &
        <a href="https://wordpress.org/plugins/stop-emails/" target="_blank">Stop Emails</a>
    </li>
    <li>Improve emails <a href="https://docs.maxim-kaminsky.com/lrm/kb/how-to-do-if-emails-are-not-delivered-to-users/" target="_blank">deliverability</a>: <a href="https://wordpress.org/plugins/wp-mail-smtp/" target="_blank">WP Mail SMTP</a></li>
</ul>
