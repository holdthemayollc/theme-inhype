<ul>
	<li><a href="https://wordpress.org/plugins/login-lockdown/" target="_blank">Login LockDown</a> (limit login attempts count)</li>
	<li><a href="https://wordpress.org/plugins/wp-facebook-login/" target="_blank">WP Facebook Login</a></li>
	<li><a href="https://wp-vote.net/" target="_blank">WP Foto Vote</a> (photo contest plugin from author of this plugin ☺)</li>
</ul>
